import React from 'react'

function WrongLetters() {
  return (
    <div className="wrong-letters-container">
    <div id="wrong-letters"></div>
  </div>
  )
}

export default WrongLetters