import React from 'react'

function Word() {
  return (
    <div className ="word" id="word"></div>
  )
}

export default Word